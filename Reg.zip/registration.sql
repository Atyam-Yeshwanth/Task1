create database reg;
use reg;
create table registration(
	user_id int not null auto_increment,
    user_name varchar(255) not null,
    user_email varchar(255) not null,
    user_password varchar(255) not null,
    primary key (user_id)
    );
select * from registration;
desc table registration;
use records;
create table records(
rec_id int not null,
rec_name varchar(255),
rec_email varchar(255),
c boolean,
cpp boolean,
ruby boolean
);

select * from records;
